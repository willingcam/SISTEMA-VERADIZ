<?php

// required headers
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: access");
header("Access-Control-Allow-Methods: GET");
header("Access-Control-Allow-Credentials: true");
header('Content-Type: application/json');

$archivo = isset($_GET['archivo']) ? $_GET['archivo'] : die();


unlink('documentos/'.$archivo);


?>
