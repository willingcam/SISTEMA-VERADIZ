﻿(function() {
    "use strict";
    var app = angular.module("veradiz.GEN.services", []);
})();