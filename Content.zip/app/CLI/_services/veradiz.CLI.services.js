﻿(function() {
    "use strict";
    var app = angular.module("veradiz.CLI.services", []);
})();