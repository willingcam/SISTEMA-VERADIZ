(function(){
    angular.module('ModuloPrincipal',[]);
  }());