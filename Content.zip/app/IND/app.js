﻿(function() {
    "use strict";

    angular.module("ModuloPrincipal", [])
        .constant('HOST', 'http://localhost/api_veradiz/Repository/Indices/')




}());