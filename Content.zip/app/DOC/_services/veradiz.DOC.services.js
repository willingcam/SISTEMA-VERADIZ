﻿(function() {
    "use strict";
    var app = angular.module("veradiz.DOC.services", []);
})();