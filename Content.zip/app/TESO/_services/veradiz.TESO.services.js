﻿(function() {
    "use strict";
    var app = angular.module("veradiz.TESO.services", []);
})();